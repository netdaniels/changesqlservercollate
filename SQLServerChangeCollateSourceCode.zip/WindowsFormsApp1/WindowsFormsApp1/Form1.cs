﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Collections;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        bool mblnErroSetup = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            fSetup(true);
        }

        private void fSetup(bool noSetup)
        {
            mblnErroSetup = false;
            txtLog.Text = "";
            txtLog.Text = "Setup iniciado .." + DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss") + Environment.NewLine;
            Application.DoEvents();
            try
            {
                string lStrSETUP = "";

                if (noSetup == false)
                {
                   lStrSETUP = File.ReadAllText(Application.StartupPath + @"\SETUP.txt");
                }
                else
                {
                    lStrSETUP = File.ReadAllText(Application.StartupPath + @"\TRUNCATE.txt");
                }



                string[] arraySetup = lStrSETUP.Split(new string[] { "GO" + "\r\n" }, StringSplitOptions.None);

                SqlConnection lcon = new SqlConnection(txtCnn.Text);
                lcon.Open();


                foreach (string comandsql in arraySetup)
                {
                    try
                    {
                        if (comandsql.Trim().Equals(""))
                        {
                            continue;
                        }
                        SqlCommand lcmd = new SqlCommand(comandsql, lcon);
                        lcmd.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        txtLog.Text = txtLog.Text + ex.Message + Environment.NewLine;
                        mblnErroSetup = true;
                    }
                }
                txtLog.Text = txtLog.Text + "Setup finalizado .." + DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss");
                lcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                mblnErroSetup = true;
            }

        }

        private void txtCnn_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            try
            {
                /*txtData.Text = "";*/
                //fSetup(false);
                //if (!mblnErroSetup)
                //{
                    fRun();
                //}
                //else
                //{
                    //MessageBox.Show("Setup com erro. Tente de novo.");
                //}
                /*
                txtMessage.Text = "Log de operações .. " ;
                Application.DoEvents();
                fViewLog();

                txtMessage.Text = "Dados gerados .. " ;
                Application.DoEvents();
                fViewGhost();
                */
                txtMessage.Text = "Arquivo de resultado .. ";
                Application.DoEvents();
                fGenerateFile();
                
            }
            catch(Exception  ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void fRun()
        {
            
            txtLog.Text = "";
            txtScript.Text = "";
            txtMessage.Text = "Execução iniciada.." + DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss") + Environment.NewLine;
            Application.DoEvents();

           
            txtLog.Text = txtLog.Text + "Em execução.. go grab some coffee..." + DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss") + Environment.NewLine;

            Application.DoEvents();

            DataTable ldtTablesWrongCollate = fGetRecords(" exec ScriptSelectTables " + "'" + txtCollate.Text + "'");


            foreach (DataRow ldr in ldtTablesWrongCollate.Rows)
            {
                DataTable ldtDropKeys = fGetRecords(" exec ScriptDropTableKeys " + "'" + ldr[0].ToString() + "'");
                foreach (DataRow ldrDropKeys in ldtDropKeys.Rows)
                {
                    txtScript.Text = txtScript.Text + ldrDropKeys[0].ToString() + "GO" + Environment.NewLine;
                }
                txtCurrent.Text = ldr[0].ToString();
                Application.DoEvents();
            }

            foreach (DataRow ldr in ldtTablesWrongCollate.Rows)
            {
                DataTable ldtDropIndex = fGetRecords(" exec ScriptDropIndexes " + "'" + ldr[0].ToString() + "'");
                foreach(DataRow ldrDropIndex in ldtDropIndex.Rows)
                {
                    txtScript.Text = txtScript.Text + ldrDropIndex[0].ToString() + Environment.NewLine + "GO" + Environment.NewLine;
                }
                txtCurrent.Text = ldr[0].ToString();
                Application.DoEvents();
            }

            foreach (DataRow ldr in ldtTablesWrongCollate.Rows)
            {
                DataTable ldtAlterColumns = fGetRecords(" exec ScriptAlterColumnCollate " + "'" + ldr[0].ToString() + "'" + "," + "'" + txtCollate.Text + "'");
                foreach (DataRow ldrAlterColumns in ldtAlterColumns.Rows)
                {
                    string lstrAlter = ldrAlterColumns[0].ToString() + Environment.NewLine + "GO" + Environment.NewLine;
                    txtScript.Text = txtScript.Text + lstrAlter.Replace("text(2147483647)", "text") ;
                }
                txtCurrent.Text = ldr[0].ToString();
                Application.DoEvents();
            }

            foreach (DataRow ldr in ldtTablesWrongCollate.Rows)
            {
                DataTable ldtCreateIndex = fGetRecords(" exec ScriptCreateIndexes " + "'" + ldr[0].ToString() + "'");
                DataTable ldtCreateKeys = fGetRecords(" exec ScriptCreateTableKeys " + "'" + ldr[0].ToString() + "'");
                DataTable ldtCreateKeysReferences = fGetRecords(" exec ScriptCreateTableKeysReferences " + "'" + ldr[0].ToString() + "'");

                foreach (DataRow ldrCreateIndex in ldtCreateIndex.Rows)
                {
                    string lstrIndex = ldrCreateIndex[0].ToString();
                    lstrIndex = lstrIndex.Replace("FILLFACTOR =0", "FILLFACTOR = 1");
                    txtScript.Text = txtScript.Text + lstrIndex + Environment.NewLine + "GO" + Environment.NewLine; ;
                }
                
                foreach (DataRow ldrCreateKeys in ldtCreateKeys.Rows)
                {
                    string lstrKey = ldrCreateKeys[0].ToString();
                    lstrKey = lstrKey.Replace("FILLFACTOR =0", "FILLFACTOR = 1");
                    txtScript.Text = txtScript.Text + lstrKey + "GO" + Environment.NewLine; ;
                } 
                
                foreach (DataRow ldrCreateKeysReferences in ldtCreateKeysReferences.Rows)
                {
                    txtScript.Text = txtScript.Text + ldrCreateKeysReferences[0].ToString() + Environment.NewLine;
                }
                txtCurrent.Text = ldr[0].ToString();
                Application.DoEvents();

            }

            DataTable ldtRefreshViews = fGetRecords(" exec ScriptRefreshViews " + "'" + txtCollate.Text + "'");

            foreach (DataRow ldr in ldtRefreshViews.Rows)
            {
                txtScript.Text = txtScript.Text + ldr[0].ToString() + Environment.NewLine + "GO" + Environment.NewLine;
            }







                txtLog.Text = txtLog.Text + "Execução finalizada .." + DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss") + Environment.NewLine;
        }

        private void fViewLog()
        {
            txtLog.Text = txtLog.Text + "Log de operação .. " + DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss") + Environment.NewLine;


            SqlConnection lcon = new SqlConnection(txtCnn.Text);
            lcon.Open();

            string lstrsql = "select dsEtapa, dtAtualizacao from TLogDeOperacao";

            SqlCommand lcmd = new SqlCommand(lstrsql, lcon);
            lcmd.CommandTimeout = 600000;
            SqlDataReader lsdr = lcmd.ExecuteReader();

            string lstrLog = "";
            while (lsdr.Read())
            {
                lstrLog = lstrLog + lsdr[0].ToString() + " - " + lsdr[1].ToString() + Environment.NewLine;
            }

            txtLog.Text = txtLog.Text + lstrLog;

            lcon.Close();

        }


        private DataTable fGetRecords(string sql)
        {
            
            SqlConnection lcon = new SqlConnection(txtCnn.Text);
            lcon.Open();

            SqlCommand lcmd = new SqlCommand(sql, lcon);
            lcmd.CommandTimeout = 600000;
            SqlDataReader lsdr = lcmd.ExecuteReader();
            DataTable ldt = new DataTable();
            ldt.Load(lsdr);
            lcon.Close();
            return ldt;

        }

        private void fGenerateFile()
        {
            string lStrVersion = "";
            string lStrDBName = "";
            string lstrFileName = "";

            DataTable ldt = fGetRecords("select @@version");
            foreach(DataRow ldr in ldt.Rows)
            {
                lStrVersion = ldr[0].ToString();
            }

            ldt = fGetRecords("select db_name()");
            foreach (DataRow ldr in ldt.Rows)
            {
                lStrDBName = ldr[0].ToString();
            }

            lstrFileName = "Resultado_" + lStrDBName + DateTime.Now.ToString("yyyMMddhhmmss") + ".txt";

            string lstrFileContent = "";

            lstrFileContent = "-- Version : " + lStrVersion + Environment.NewLine;
            lstrFileContent = lstrFileContent + "-- Database name : " + lStrDBName + Environment.NewLine + Environment.NewLine;
            lstrFileContent = lstrFileContent + txtScript.Text + Environment.NewLine;

            File.WriteAllText(Application.StartupPath + "\\" + lstrFileName, lstrFileContent);

            txtFile.Text = Application.StartupPath + "\\" + lstrFileName;
            

        }

        private void nudMes_ValueChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        public void fillGhostContent(string pGhostTable, string pTimeStamp, string pTag)
        {
            ArrayList lGT = new ArrayList();

            // Assume failure.
            string returnValue = null;

            // Look for the name in the connectionStrings section.
            returnValue = txtCnn.Text;

            SqlConnection lCon = new SqlConnection(returnValue);
            SqlCommand lCmd = new SqlCommand("select * from " + pGhostTable);
            lCmd.Connection = lCon;
            lCon.Open();

            SqlDataReader lDr = lCmd.ExecuteReader();

            string strUTC = pTimeStamp;
            while (lDr.Read())
            {
                string theRecord = "";
                for (int i = 0; (i <= lDr.FieldCount - 1); i++)
                {
                    theRecord = theRecord + lDr[i].ToString();
                }

                string sqlInsert = " INSERT INTO TGhostTabelaConteudo ( dsGhostTabela,dsUsername,datCriacao,dsHash, dsTodosOsCampos, dsObs) ";
                sqlInsert = sqlInsert + "SELECT ";
                sqlInsert = sqlInsert + "'" + pGhostTable + "'" + ",";
                sqlInsert = sqlInsert + "'" + Environment.UserName + "'" + ",";
                sqlInsert = sqlInsert + "'" + strUTC + "'" + ",";
                sqlInsert = sqlInsert + "'" + theRecord.GetHashCode() + "'" + ",";
                sqlInsert = sqlInsert + "'" + theRecord.Replace("'", "") + "'" + ",";
                sqlInsert = sqlInsert + "'" + pTag.Replace("'", "") + "'";

                execCommand(sqlInsert);
            }

            lCon.Close();
            lCon = null;
        }
        public void execCommand(string sql)
        {

            // Assume failure.
            string returnValue = null;

            // Look for the name in the connectionStrings section.
            returnValue = txtCnn.Text;

            SqlConnection lCon = new SqlConnection(returnValue);
            SqlCommand lCmd = new SqlCommand(sql);
            lCmd.Connection = lCon;
            lCon.Open();
            lCmd.ExecuteNonQuery();
            lCon.Close();
            lCon = null;
        }

        private void dtFim_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dtInicio_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
           
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            try
            {
                txtScript.Text = "";
                string lstrChangeDatabaseCollation = "";

                lstrChangeDatabaseCollation = "alter database {banco} ";
                lstrChangeDatabaseCollation = lstrChangeDatabaseCollation + "set single_user with rollback immediate;" + Environment.NewLine;
                lstrChangeDatabaseCollation = lstrChangeDatabaseCollation + "go" + Environment.NewLine;
                lstrChangeDatabaseCollation = lstrChangeDatabaseCollation + "alter database {banco} collate {collate};" + Environment.NewLine;
                lstrChangeDatabaseCollation = lstrChangeDatabaseCollation + "go" + Environment.NewLine;
                lstrChangeDatabaseCollation = lstrChangeDatabaseCollation + "alter database {banco} ";
                lstrChangeDatabaseCollation = lstrChangeDatabaseCollation + "set multi_user;" + Environment.NewLine;

                lstrChangeDatabaseCollation = lstrChangeDatabaseCollation.Replace("{banco}", txtBanco.Text).Replace("{collate}", txtCollate.Text);

                txtScript.Text = lstrChangeDatabaseCollation;

                txtMessage.Text = "Arquivo de resultado .. ";
                Application.DoEvents();
                fGenerateFile();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                txtScript.Text = "";
                fnExcluirFuncoes();
                txtMessage.Text = "Arquivo de resultado .. ";
                Application.DoEvents();
                fGenerateFile();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);

            }


        }

        private void fnExcluirFuncoes()
        {
            DataTable ldtDropFunction = fGetRecords(" SELECT ' DROP FUNCTION ' + NAME FROM SYSOBJECTS WHERE XTYPE IN ('TF','FN') ");

            foreach (DataRow ldr in ldtDropFunction.Rows)
            {
               txtScript.Text = txtScript.Text + ldr[0].ToString() + Environment.NewLine + "GO" + Environment.NewLine;
               txtCurrent.Text = ldr[0].ToString();
               Application.DoEvents();
            }

            

        }

        private void fnViewsCollateErrado()
        {
            txtScript.Text = "";

            DataTable ldtDropFunction = fGetRecords(" exec ScriptSelectViews " + "'" + txtCollate.Text + "'");

            foreach (DataRow ldr in ldtDropFunction.Rows)
            {
                txtScript.Text = txtScript.Text + ldr[0].ToString() + Environment.NewLine ;
                txtCurrent.Text = ldr[0].ToString();
                Application.DoEvents();
            }



        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                fnViewsCollateErrado();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
